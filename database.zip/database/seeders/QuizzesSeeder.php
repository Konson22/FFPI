<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class QuizzesSeeder extends Seeder
{
    public function run(): void
    {
        $lessons = DB::table('lessons')->select('id', 'title')->orderBy('id')->limit(10)->get();

        if ($lessons->isEmpty()) {
            $this->command?->warn('No lessons found. Skipping QuizzesSeeder.');
            return;
        }

        $now = Carbon::now();
        $rows = [];

        foreach ($lessons as $lesson) {
            $rows[] = [
                'lesson_id' => $lesson->id,
                'question' => 'What is the key takeaway from "'.$lesson->title.'"?',
                'correct_answer' => 'See lesson summary',
                'created_at' => $now,
                'updated_at' => $now,
            ];

            $rows[] = [
                'lesson_id' => $lesson->id,
                'question' => 'Which statement best reflects a safe practice discussed in this lesson?',
                'correct_answer' => 'Follow recommended guidance from the lesson',
                'created_at' => $now,
                'updated_at' => $now,
            ];
        }

        DB::table('quizzes')->insert($rows);
    }
}


